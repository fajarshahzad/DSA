import matplotlib.pyplot as plt  
import pandas as pd 
########################Part 1.1#########################################
df = pd.read_csv('C:/Users/dell/Desktop/DSA(L)/Week3/population_by_country_2020.csv' )  
 
 
print(df.dtypes) 
list1 = df['Country (or dependency)'].values.tolist()  
list2 = df['Population (2020)'].values.tolist()
 
plt.bar(list1[:15], list2[:15],width = 1, color = ['blue', 'green']) 
 
plt.show() 
#############################Part 1.2###########################################
df = pd.read_csv('C:/Users/dell/Desktop/DSA(L)/Week3/CSV/dailySteps_merged.csv' )  
 
 
print(df.dtypes) 
list1 = df['ActivityDay'].values.tolist()  
list2 = df['StepTotal'].values.tolist()

plt.plot(list1[:8], list2[:8]) 
 
plt.show()
###########################Part 1.3############################################
df = pd.read_csv('C:/Users/dell/Desktop/DSA(L)/Week3/CSV/dailyActivity_merged.csv' )  
 
 
print(df.dtypes) 
list1 = df['ActivityDate'].values.tolist()  
list2 = df['TotalSteps'].values.tolist()
list3 = df['TotalDistance'].values.tolist()
plt.bar(list1[:8], list2[:8],list3[:8],color=['blue','yellow','black']) 
 
plt.show()
############################Part 1.4 ########################################
df = pd.read_csv('C:/Users/dell/Desktop/DSA(L)/Week3/CSV/sleepDay_merged.csv' )  
 
 
print(df.dtypes) 
list1 = df['TotalTimeInBed'].values.tolist()
list2 = df['TotalSleepRecords'].values.tolist() 
plt.scatter(list1[:8],list2[:8]) 
 
plt.show()
##############################Part 1.5#######################################
data = pd.read_csv('C:/Users/dell/Desktop/DSA(L)/Week3/CSV/hourlySteps_merged.csv')
data['ActivityHour'] = pd.to_datetime(data['ActivityHour'])  
filtered_data = data[data['ActivityHour'].dt.date == pd.to_datetime('2016-04-12').date()]
filtered_data['Hour'] = filtered_data['ActivityHour'].dt.strftime('%I %p') 
hours = filtered_data['Hour']
steps = filtered_data['StepTotal']
plt.figure(figsize=(8, 8))
plt.pie(steps, labels=hours, autopct='%1.1f%%', startangle=90)
plt.show()

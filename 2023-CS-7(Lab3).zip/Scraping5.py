from bs4 import BeautifulSoup
import requests
import pandas as pd
web_url=(r'https://en.wikipedia.org/wiki/List_of_largest_oil_and_gas_companies_by_revenue')
page = requests.get(web_url)
soup = BeautifulSoup(page.text,'html.parser')
table = soup.find('table',class_='wikitable sortable')
company_titles=table.find_all('th')
company_table_titles=[title.text.strip() for title in company_titles]
print(company_table_titles)
df=pd.DataFrame(columns=company_table_titles)
column_data=table.find_all('tr')
for row in column_data[1:]:
    row_data=row.find_all('td')
    single_row_data=[data.text.strip() for data in row_data]
    length=len(df)
    df.loc[length]=single_row_data
print(df)
df.to_csv(r'C:\Users\dell\Desktop\Semester3\DSA(L)\Week3\Oil&Gas Companies.csv',index=False)
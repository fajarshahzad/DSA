from selenium import webdriver  
from bs4 import BeautifulSoup  
from selenium.webdriver.chrome.service import Service
import pandas as pd 
service = Service(
    executable_path=r"C:/Users/dell/Desktop/Semester3/DSA(L)/chromedriver-win64/chromedriver-win64/chromedriver.exe"
)
options = webdriver.ChromeOptions()
driver = webdriver.Chrome(service=service, options=options) 
products=[] #List to store name of the product 
prices=[] #List to store price of the product 
ratings=[] #List to store rating of the product 
driver.get("https://www.flipkart.com/gaminglaptops- store?otracker=nmenu_sub_Electronics_0_Gaming%20Laptops&otracker=nmenu_sub_E lectr onics_0_Gaming%20Laptops")    
content = driver.page_source  
soup = BeautifulSoup(content,features='html.parser')  # print(soup)  
for a in soup.findAll('div',attrs={'class':'_37K3-p'}):      
    print (a)       
    name=a.find('a', attrs={'class':'s1Q9rs'})          
    price=a.find('div',attrs={'class':'_30jeq3'})        
    rating=a.find('div',attrs={'class':'_3LWZlK'})           
    products.append(name.text)           
    prices.append(price.text)      
    ratings.append(rating.text)
    if len(products) == 50:
        break
   
df = pd.DataFrame({'Product Name':products,'Price':prices,'Rating':ratings})   
df.to_csv('Flipcart.csv', index=False, encoding='utf-8') 
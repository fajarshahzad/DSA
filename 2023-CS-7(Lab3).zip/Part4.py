from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd
from selenium.webdriver.chrome.service import Service
import time as sleep

service = Service(
    executable_path=r'C:/Users/dell/Desktop/Semester3/DSA(L)/chromedriver-win64/chromedriver-win64/chromedriver.exe'
)
options = webdriver.ChromeOptions()
driver = webdriver.Chrome(service=service, options=options)
CourseCode = []
Title = []
Description = []
CLO = []
TextBook = []  
driver.get("http://eduko.spikotech.com/Course/Details/2073")

content = driver.page_source

soup = BeautifulSoup(content, features="html.parser")
for a in soup.findAll("div", attrs={"class": "body-content"}):
    print(a)
    CourseCode = a.find("div", attrs={"id": "CourseCode"})
    Title = a.find("h5",attrs={"id":"CourseName"})
    Description = a.find("p",attrs={"id":"CourseDescription"})
    CLO = a.find("ul",attrs={"id","CourseClos"})
    TextBook = a.find("ul", attrs={"id": "CourseBooks"})
    CourseCode.append(CourseCode.text)
    Title.append(Title.text)
    Description.append(Description.text)
    CLO.append(CLO.text)
    TextBook.append(TextBook.text)

df = pd.DataFrame({"Course code": CourseCode, "Title": Title,"Description": Description,"CLO": CLO,"TextBook": TextBook})
df.to_csv("EdukoSpike.csv", index=False, encoding="utf-8")
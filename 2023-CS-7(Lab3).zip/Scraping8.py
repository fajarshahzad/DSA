from bs4 import BeautifulSoup
import requests
import pandas as pd

web_url = r'https://en.wikipedia.org/wiki/List_of_companies_of_India'
page = requests.get(web_url)
soup = BeautifulSoup(page.text, 'html.parser')
table = soup.find('table', class_='wikitable sortable')
INRCompanies_titles = table.find_all('th')
Companies_table_titles = [title.text.strip() for title in INRCompanies_titles]
print(Companies_table_titles)
df = pd.DataFrame(columns=Companies_table_titles)
column_data = table.find_all('tr')

for row in column_data[1:]:  
    row_data = row.find_all('td')
    single_row_data = [data.text.strip() for data in row_data]
    length = len(df)
    df.loc[length] = single_row_data
print(df)
df.to_csv(r'C:\Users\dell\Desktop\Semester3\DSA(L)\Week3\IndianCompanies.csv', index=False)
from bs4 import BeautifulSoup
import requests
import pandas as pd
import numpy as np  # For using np.nan to pad missing data

web_url = r'https://en.wikipedia.org/wiki/List_of_photovoltaics_companies'
page = requests.get(web_url)
soup = BeautifulSoup(page.text, 'html.parser')
table = soup.find('table', class_='wikitable sortable')
PVCompanies_titles = table.find_all('th')
PVCompanies_table_titles = [title.text.strip() for title in PVCompanies_titles]
print(PVCompanies_table_titles)
df = pd.DataFrame(columns=PVCompanies_table_titles)
column_data = table.find_all('tr')

for row in column_data[1:]:  
    row_data = row.find_all('td')
    single_row_data = [data.text.strip() for data in row_data]
    
    # If there are fewer columns in the row, pad with None or NaN
    if len(single_row_data) < len(PVCompanies_table_titles):
        single_row_data += [np.nan] * (len(PVCompanies_table_titles) - len(single_row_data))
    
    # If there are more columns, trim the extra data
    elif len(single_row_data) > len(PVCompanies_table_titles):
        single_row_data = single_row_data[:len(PVCompanies_table_titles)]
    length = len(df)
    df.loc[length] = single_row_data
print(df)
df.to_csv(r'C:\Users\dell\Desktop\Semester3\DSA(L)\Week3\PhotoVoltaicsCompanies.csv', index=False)
import pandas as pd
import matplotlib.pyplot as plt

# Load dataset from a given URL
def load_data(data_url):
    df = pd.read_csv(data_url)
    print("Data Loaded Successfully!")
    print(df.head())  # Display the first few rows of the data
    return df

# Plot scatter plots between each symptom and the label
def plot_symptoms_vs_label(df, label_column):
    symptom_columns = df.columns.drop(label_column)  # Get all columns except the label
    
    for symptom in symptom_columns:
        plt.figure(figsize=(6, 4))
        plt.scatter(df[symptom], df[label_column], alpha=0.5)
        plt.title(f'Scatter plot: {symptom} vs {label_column}')
        plt.xlabel(symptom)
        plt.ylabel(label_column)
        plt.show()

# Compare test data with training data based on symptoms
def compare_test_with_training(train_df, test_df, label_column):
    symptom_columns = train_df.columns.drop(label_column)  # Get symptom columns only
    
    for i, test_row in test_df.iterrows():
        print(f"\nComparing Test Data Row {i + 1} with Training Data")
        match_found = False
        for j, train_row in train_df.iterrows():
            # Check if all symptoms match between the test row and a training row
            if all(test_row[symptom] == train_row[symptom] for symptom in symptom_columns):
                print(f"Test row {i + 1} matches training row {j + 1} with label {train_row[label_column]}")
                match_found = True
                break
        if not match_found:
            print(f"No match found for test row {i + 1}")

# Main function to run all the tasks
def main():
    # Load training data
    train_data_url = (r'C:/Users/dell/Desktop/Semester3/DSA(L)/Week3/CSV/Train.csv') # Replace with the correct training data URL or file path
    train_df = load_data(train_data_url)
    
    # Define the label column
    label_column = 'TYPE'  # Adjust this based on your actual label column name
    
    # Plot scatter plots for symptoms vs label
    print("Plotting Scatter Graphs for Each Symptom vs type...")
    plot_symptoms_vs_label(train_df, label_column)
    
    # Load test data
    test_data_url = (r'C:/Users/dell/Desktop/Semester3/DSA(L)/Week3/CSV/Test.csv')  # Replace with the correct test data URL or file path
    test_df = load_data(test_data_url)
    
    # Compare test data with training data
    print("\nComparing Test Data with Training Data...")
    compare_test_with_training(train_df, test_df, label_column)

# Run the main function
if __name__ == "__main__":
    main()

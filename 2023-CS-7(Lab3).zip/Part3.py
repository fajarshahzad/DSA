######################### 1. Print matrix ######################################
def printMatrix(A, starting_index, rows, columns):
    x, y = starting_index
    print(f"Printing matrix from index {starting_index} with size {rows}x{columns}:")
    for i in range(x, x + rows):
        for j in range(y, y + columns):
            print(A[i][j], end=" ")
        print()
    print()

################################# 2. Matrix Addition #######################################
def MatAdd(A, B):
    rows = len(A)
    cols = len(A[0])
    C = [[0 for _ in range(cols)] for _ in range(rows)]
    
    for i in range(rows):
        for j in range(cols):
            C[i][j] = A[i][j] + B[i][j]
    
    return C

######################################## 3. Partial Matrix Addition ##################################
def MatAddPartial(A, B, start, size):
    x, y = start
    C = [[0 for _ in range(size)] for _ in range(size)]
    
    for i in range(size):
        for j in range(size):
            C[i][j] = A[x + i][y + j] + B[x + i][y + j]
    
    return C

############################################## 4. Iterative Matrix Multiplication ###################################
def MatMul(A, B):
    rows_A = len(A)
    cols_A = len(A[0])
    rows_B = len(B)
    cols_B = len(B[0])
    
    if cols_A != rows_B:
        raise ValueError("Matrices cannot be multiplied (A columns != B rows)")
    
    C = [[0 for _ in range(cols_B)] for _ in range(rows_A)]
    
    for i in range(rows_A):
        for j in range(cols_B):
            for k in range(cols_A):
                C[i][j] += A[i][k] * B[k][j]
    
    return C

############################## 5. Recursive Matrix Multiplication ########################################## 
def MatMulRecursive(A, B):
    n = len(A)
    
    if n == 1:
        return [[A[0][0] * B[0][0]]]
    
    mid = n // 2
    A11 = [row[:mid] for row in A[:mid]]
    A12 = [row[mid:] for row in A[:mid]]
    A21 = [row[:mid] for row in A[mid:]]
    A22 = [row[mid:] for row in A[mid:]]
    
    B11 = [row[:mid] for row in B[:mid]]
    B12 = [row[mid:] for row in B[:mid]]
    B21 = [row[:mid] for row in B[mid:]]
    B22 = [row[mid:] for row in B[mid:]]
    
    C11 = MatAdd(MatMulRecursive(A11, B11), MatMulRecursive(A12, B21))
    C12 = MatAdd(MatMulRecursive(A11, B12), MatMulRecursive(A12, B22))
    C21 = MatAdd(MatMulRecursive(A21, B11), MatMulRecursive(A22, B21))
    C22 = MatAdd(MatMulRecursive(A21, B12), MatMulRecursive(A22, B22))
    
    C = []
    for i in range(mid):
        C.append(C11[i] + C12[i])
    for i in range(mid):
        C.append(C21[i] + C22[i])
    
    return C

################################################## 6. Strassen Matrix Multiplication ####################################
def MatMulStrassen(A, B):
    n = len(A)
    
    if n == 1:
        return [[A[0][0] * B[0][0]]]
    
    mid = n // 2
    A11 = [row[:mid] for row in A[:mid]]
    A12 = [row[mid:] for row in A[:mid]]
    A21 = [row[:mid] for row in A[mid:]]
    A22 = [row[mid:] for row in A[mid:]]
    
    B11 = [row[:mid] for row in B[:mid]]
    B12 = [row[mid:] for row in B[:mid]]
    B21 = [row[:mid] for row in B[mid:]]
    B22 = [row[mid:] for row in B[mid:]]
    
    M1 = MatMulStrassen(MatAdd(A11, A22), MatAdd(B11, B22))
    M2 = MatMulStrassen(MatAdd(A21, A22), B11)
    M3 = MatMulStrassen(A11, MatAdd(B12, B22))
    M4 = MatMulStrassen(A22, MatAdd(B21, B11))
    M5 = MatMulStrassen(MatAdd(A11, A12), B22)
    M6 = MatMulStrassen(MatAdd(A21, A11), MatAdd(B11, B12))
    M7 = MatMulStrassen(MatAdd(A12, A22), MatAdd(B21, B22))
    
    C11 = MatAdd(MatAdd(M1, M4), MatAdd(M7, M5))
    C12 = MatAdd(M3, M5)
    C21 = MatAdd(M2, M4)
    C22 = MatAdd(MatAdd(M1, M3), MatAdd(M6, M2))
    
    C = []
    for i in range(mid):
        C.append(C11[i] + C12[i])
    for i in range(mid):
        C.append(C21[i] + C22[i])
    
    return C
def displayMatrix(matrix):
    for row in matrix:
        print(" ".join(map(str, row)))
    print()

######################################### Main ##########################################
def main():
    A = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12],
        [13, 14, 15, 16]
    ]
    
    B = [
        [16, 15, 14, 13],
        [12, 11, 10, 9],
        [8, 7, 6, 5],
        [4, 3, 2, 1]
    ]
    
    print("Matrix A:")
    displayMatrix(A)
    
    print("Matrix B:")
    displayMatrix(B)
    
    # Testing printMatrix
    print("Testing printMatrix from (1, 2) with 2x2:")
    printMatrix(A, (1, 2), 2, 2)
    
    # Testing MatAdd
    print("Testing Matrix Addition:")
    C = MatAdd(A, B)
    displayMatrix(C)
    
    # Testing MatAddPartial
    print("Testing Partial Matrix Addition (from (1, 1), size 2):")
    D = MatAddPartial(A, B, (1, 1), 2)
    displayMatrix(D)
    
    # Testing MatMul (Iterative)
    print("Testing Matrix Multiplication (Iterative):")
    E = MatMul(A, B)
    displayMatrix(E)
    
    # Testing MatMulRecursive
    print("Testing Matrix Multiplication (Recursive):")
    F = MatMulRecursive(A, B)
    displayMatrix(F)
    
    # Testing MatMulStrassen
    print("Testing Matrix Multiplication (Strassen):")
    G = MatMulStrassen(A, B)
    displayMatrix(G)

# Run the main method
if __name__ == "__main__":
    main()

from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd
from selenium.webdriver.chrome.service import Service
import time

# Set up Selenium WebDriver with Chrome
service = Service(
    executable_path=r'C:/Users/dell/Desktop/Semester3/DSA(L)/chromedriver-win64/chromedriver-win64/chromedriver.exe'
)
options = webdriver.ChromeOptions()
driver = webdriver.Chrome(service=service, options=options)

# URL of the Daraz product page to scrape
daraz_url = "https://www.daraz.pk/catalog/?q=laptops"  # Replace with any product category URL

# Open the URL in the browser
driver.get(daraz_url)

# Wait for the page to load
time.sleep(5)  # Adjust sleep time if necessary

# Get the page content
content = driver.page_source
soup = BeautifulSoup(content, 'html.parser')

# Lists to store product details
products = []

# Loop through each product block
for item in soup.find_all('div', class_='c1_t2i'):
    # Extract product name
    product_name = item.find('a', class_='c16H9d').get_text() if item.find('a', class_='c16H9d') else 'N/A'
    
    # Extract price
    price = item.find('span', class_='c3gUW0').get_text() if item.find('span', class_='c3gUW0') else 'N/A'
    
    # Extract original price (if available)
    original_price = item.find('del', class_='c13VH6').get_text() if item.find('del', class_='c13VH6') else 'N/A'
    
    # Extract discount (if available)
    discount = item.find('span', class_='c1-Bfs').get_text() if item.find('span', class_='c1-Bfs') else 'N/A'
    
    # Extract ratings (if available)
    rating = item.find('span', class_='c3XbGJ').get_text() if item.find('span', class_='c3XbGJ') else 'N/A'
    
    # Extract the number of reviews (if available)
    reviews = item.find('span', class_='c3XbGJ').find_next('a').get_text() if item.find('span', class_='c3XbGJ') else 'N/A'
    
    # Extract product link
    product_link = 'https:' + item.find('a', class_='c16H9d')['href'] if item.find('a', class_='c16H9d') else 'N/A'
    
    # Append product details to the list
    products.append({
        'Product Name': product_name,
        'Price': price,
        'Original Price': original_price,
        'Discount': discount,
        'Rating': rating,
        'Reviews': reviews,
        'Product Link': product_link
    })

# Print product details
for index, product in enumerate(products):
    print(f"Product {index + 1}:")
    for key, value in product.items():
        print(f"{key}: {value}")
    print("-" * 40)

# Save the scraped data to a CSV file
df = pd.DataFrame(products)
df.to_csv('daraz_products_selenium.csv', index=False, encoding='utf-8')

# Close the Selenium browser
driver.quit()

import funcs
import time
def display_menu():
    print("Please choose an option from the menu:")
    print("1. MergeSort")
    print("2. BubbleSort")
    print("3. InsertionSort")
    print("4. SelectionSort")
    print("5. HybridMergeSort")
    print("6. Exit")
# Function to run the menu and take input
def menu():
    print("Run Time Game:)")
    start=int(input("Enter the starting index of the array: "))
    end=int(input("Enter the ending index of the array: "))
    file_path = 'c:/Users/dell/Desktop/DSA(L)/Week2/Nvalues.txt'
    while True:
        display_menu()
        choice = input("Enter your choice (1-6): ")
        if choice == '1':
            values = funcs.read_values(file_path)
            for value in values:
                random_array = funcs.RandomArray(value)
                start_time=time.time()
                funcs.MergeSort(random_array,start,end)
                end_time=time.time()
                run_time=end_time-start_time
                print(f"Sorted array for value '{value}' is : ",random_array)
                print(f"Runtime is '{run_time}'seconds")
                funcs.store_algorithm_data("MergeSort",value,run_time,"RunTime.csv")
        elif choice == '2':
            values = funcs.read_values(file_path)
            for value in values:
                random_array = funcs.RandomArray(value)
                start_time=time.time()
                result=funcs.BubbleSort(random_array,start,end)
                end_time=time.time()
                run_time=end_time-start_time
                print(f"Sorted array for value '{value}' is : ",result)
                print(f"Runtime is '{run_time}'seconds")
                funcs.store_algorithm_data("BubbleSort",value,run_time,"RunTime.csv")
        elif choice == '3':
            values = funcs.read_values(file_path)
            for value in values:
                random_array = funcs.RandomArray(value)
                start_time=time.time()
                funcs.InsertionSort(random_array,start,end)
                end_time=time.time()
                run_time=end_time-start_time
                print(f"Sorted array for value '{value}' is : ",random_array)
                print(f"Runtime is '{run_time}'seconds")
                funcs.store_algorithm_data("InsertionSort",value,run_time,"RunTime.csv")
        elif choice == '4':
            values = funcs.read_values(file_path)
            for value in values:
                random_array = funcs.RandomArray(value)
                start_time=time.time()
                result=funcs.SelectionSort(random_array,start,end)
                end_time=time.time()
                run_time=end_time-start_time
                print(f"Sorted array for value '{value}' is : ",result)
                print(f"Runtime is '{run_time}'seconds")
                funcs.store_algorithm_data("SelectionSort",value,run_time,"RunTime.csv")
        elif choice == '5':
            values = funcs.read_values(file_path)
            for value in values:
                random_array = funcs.RandomArray(value)
                start_time=time.time()
                funcs.HybridMergeSort(random_array,start,end)
                end_time=time.time()
                run_time=end_time-start_time
                print(f"Sorted array for value '{value}' is : ",random_array)
                print(f"Runtime is '{run_time}'seconds")
                funcs.store_algorithm_data("HybridMergeSort",value,run_time,"RunTime.csv")
        elif choice == '6':
            print("Exiting.......")
            break
        else:
            print("Invalid choice, please try again.")

# Run the menu
menu()
import random
import csv
### Random Array
def RandomArray(array_size):
    randomArray=[]
    min=-15000
    max=15000
    for i in range(0,array_size):
        randomArray.append(random.randint(min,max))
    return randomArray
### Raed file 
def read_words_from_file(file_path):
    with open(file_path, 'r') as file:
        words = [line.strip() for line in file if line.strip()]
    return words
### Shuffle Array
def ShuffleArray(array, start, end):
    subarray = array[start:end+1]
    random.shuffle(subarray)
    array[start:end+1] = subarray
### Save to file
def save_to_file(file_name,array):
    with open(file_name,"w") as file:
        writer=csv.writer(file,delimiter='\n')
        writer.writerow(array)
### Store Algorithm Rum time
def store_algorithm_data(algorithm_name, array_size, time_taken, file_name):
    with open(file_name, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([algorithm_name, array_size, time_taken])
### Insertion Sort
def InsertionSort(array,start,end):
    for i in range(start+1,end+1):
        key=array[i]
        j=i-1
        while j>=start and array[j]>key:
            array[j+1]=array[j]
            j-=1
        array[j+1]=key
### Merge arrays
def Merge(array,p,q,r):
    left_half = array[p:q+1]
    right_half = array[q+1:r+1]

    i = j = 0 
    k = p  
    while i < len(left_half) and j < len(right_half):
        if left_half[i] <= right_half[j]:
            array[k] = left_half[i]
            i += 1
        else:
            array[k] = right_half[j]
            j += 1
        k += 1
    while i < len(left_half):
        array[k] = left_half[i]
        i += 1
        k += 1
    while j < len(right_half):
        array[k] = right_half[j]
        j += 1
        k += 1
### Merge Sort
def MergeSort(Array, start_index, end_index):
    if start_index < end_index:
        mid = (start_index + end_index) // 2  
        MergeSort(Array, start_index, mid)
        MergeSort(Array,  mid+ 1, end_index)
        Merge(Array,start_index,mid,end_index)  
### Bubble Sort
def BubbleSort(array,start,end):
    for i in range(start,end):
        for j in range(start,end-i+start):
            if(array[j]> array[j+1]):
                array[j],array[j+1]=array[j+1],array[j]
    return array
### Selection Sort
def SelectionSort(array,start,end):
    for i in range(start,end+1):
        min_index =i
        for j in range (i+1,end+1):
            if array[j]<array[min_index]:
                min_index=j
        array[min_index],array[i]=array[i],array[min_index]
    return array
### Hybrid Merge Sort
def HybridMergeSort(Array, start_index, end_index):
    if end_index - start_index <= 5:
        InsertionSort(Array, start_index, end_index)
    else:
        if start_index < end_index:
            mid = (start_index + end_index) // 2  
            HybridMergeSort(Array, start_index, mid)
            HybridMergeSort(Array, mid + 1, end_index)
            Merge(Array, start_index, mid, end_index)
### Read numbers file
def read_values(file_path):
    values = []
    try:
        # Open the file in read mode
        with open(file_path, 'r') as file:
            # Read each line, strip newline characters, and append to the list
            for line in file:
                value = line.strip()  # Remove leading/trailing whitespace (including newlines)
                if value:  # Ensure non-empty lines
                    try:
                        yield int(value)  # Try to convert to integer
                    except ValueError:
                        print(f"Warning: '{value}' is not a valid integer and will be skipped.")
                        continue  # Skip invalid values
                    values.append(value)
        return values
    except FileNotFoundError:
        print(f"Error: The file {file_path} was not found.")
        return None
### Main
if __name__=="__main__":
    size=15
    result=RandomArray(size)
    print(result)
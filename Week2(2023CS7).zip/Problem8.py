import time
import funcs
def main():
    file_path = 'c:/Users/dell/Desktop/DSA(L)/Week2/Words.txt'
    
    words = funcs.read_words_from_file(file_path)
    print("Original Array: ",words)
    # Perform sorting without shuffling
    print("Sorting without shuffling:")
    words_copy = words.copy()
    start_time=time.time()
    funcs.InsertionSort(words_copy,0,len(words_copy)-1)
    end_time=time.time()
    insertion_sort_time = end_time-start_time
    print(f"Insertion Sort took {insertion_sort_time:.8f} seconds.")
    words_copy = words.copy()
    start_time=time.time()
    funcs.MergeSort(words_copy,0,len(words_copy)-1)
    end_time=time.time()
    merge_sort_time = end_time-start_time
    print(f"Merge Sort took {merge_sort_time:.8f} seconds.")
    # Shuffle the array
    funcs.ShuffleArray(words, 0, len(words_copy) - 1)
    print("Array affter shuffling: ",words)
    # Perform sorting after shuffling
    print("\nSorting after shuffling:")
    words_copy = words.copy()
    start_time=time.time()
    funcs.InsertionSort(words_copy,0,len(words_copy)-1)
    end_time=time.time()
    insertion_sort_time = end_time-start_time
    print(f"Insertion Sort took {insertion_sort_time:.8f} seconds after shuffling.")
    words_copy = words.copy()
    start_time=time.time()
    funcs.MergeSort(words_copy,0,len(words)-1)
    end_time=time.time()
    merge_sort_time = end_time-start_time
    print(f"Merge Sort took {merge_sort_time:.8f} seconds after shuffling.")
    
    # Conclusion
    print("\nConclusion:Merge Sort generally outperforms Insertion Sort, especially on larger datasets. Shuffling affects Insertion Sort more due to its sensitivity to initial order, while Merge Sort remains efficient regardless of the input order.")

# main
if __name__ == "__main__":
    main()

def factorial(a):
    if(a==0):
        return 1
    else:
        return a*factorial(a-1)
import time
start_time=time.time()
a=995
result=factorial(a)
end_time=time.time()
run_time=start_time-end_time
print(result)
print("Runtime of factorial at ",a,"is",run_time,"seconds")
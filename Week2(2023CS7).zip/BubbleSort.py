import funcs
import time
#main
size=int(input("Enter the size of the array: "))
start=int(input("Enter the starting index of the array: "))
end=int(input("Enter the ending index of the array: "))
Array=funcs.RandomArray(size)
print("Actual array: ",Array)
start_time=time.time()
result=funcs.BubbleSort(Array,start,end)
end_time=time.time()
run_time=end_time-start_time
print("Bubble Sorted array is: ",result)
print("Runtime is: ",run_time,"seconds")
funcs.save_to_file("SortedBubbleSort.csv",result)

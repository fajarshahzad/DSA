#include <iostream>
//#include <stack>
#include <string>
using namespace std;
class Stack {
public:
    char* arr;
    int top;
    int maxsiz=100;

public:
    Stack() {;
        arr = new char[maxsiz];
        top = -1;
    }

    ~Stack() {
        delete[] arr;
    }

    bool isEmpty() {
        return top == -1;
    }

    bool isFull() {
        return top == maxsiz - 1;
    }

    void push(char x) {
        if (isFull()) {
            cout << "Stack Overflow!" << endl;
            return;
        }
        arr[++top] = x;
    }

    char pop() {
        if (isEmpty()) {
            cout << "Stack Underflow!" << endl;
            //return ;
        }
        return arr[top--];
    }

    //

    void display() {
        for (int i = top; i >= 0; i--) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    char peek() {
        if (isEmpty()) {
            cout << "Stack is empty!" << endl;
            //return -1;
        }
        return arr[top];
    }
};
void reverseString(string& str) 
{
    int start=0;
    int end=str.length()-1;
    while (start<end) {
        char temp=str[start];
        str[start]=str[end];
        str[end]=temp;
        start++;
        end--;
    }
}
string reverseSentence(const string& sentence) 
{
    Stack stk;
    string result="";
    for (int i=0;i<sentence.length();i++) 
	{
        if (sentence[i]!=' ') 
		{
            stk.push(sentence[i]);
        } else {
            while (!stk.isEmpty()) 
			{
                result+=stk.peek();
                stk.pop();
            }
            result+=' ';
        }
    }
    while (!stk.isEmpty()) 
	{
        result+=stk.peek();
        stk.pop();
    }
    reverseString(result); 
    return result;
}
int main() 
{
    string sentence;
    cout<<"Enter the string: ";
    getline(cin,sentence);
    string output = reverseSentence(sentence);
    cout<<"Reversed string: "<<output<<endl;
    return 0;
}

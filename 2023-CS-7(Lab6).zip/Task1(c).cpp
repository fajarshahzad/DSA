#include <iostream>
using namespace std;
class Queue 
{
private:
    int* arr;
    int front, rear, maxSize;

public:
    Queue(int size) 
	{
        maxSize = size;
        arr = new int[maxSize];
        front = rear = -1;
    }

    ~Queue() 
	{
        delete[] arr;
    }

    bool isEmpty() 
	{
        return front == -1;
    }

    bool isFull() 
	{
        return rear == maxSize - 1;
    }

    void enqueue(int x)
	{
        if (isFull()) {
            cout << "Queue Overflow!" << endl;
            return;
        }
        if (isEmpty()) {
            front = rear = 0;
        } else {
            rear++;
        }
        arr[rear] = x;
    }

    int dequeue() 
	{
        if (isEmpty()) {
            cout << "Queue Underflow!" << endl;
            return -1;
        }
        int temp = arr[front];
        if (front == rear) {
            front = rear = -1;
        } else {
            front++;
        }
        return temp;
    }

    int peek() 
	{
        if (isEmpty()) 
		{
            cout << "Queue is empty!" << endl;
            return -1;
        }
        return arr[front];
    }

    void display() 
	{
        if (isEmpty()) {
            cout << "Queue is empty!" << endl;
            return;
        }
        for (int i = front; i <= rear; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main() 
{
    Queue queue(5);
    queue.enqueue(10);
    queue.enqueue(20);
    queue.enqueue(30);
    cout << "Queue: ";
    queue.display();
    cout << "Front element: " << queue.peek() << endl;
    cout << "Dequeued element: " << queue.dequeue() << endl;
    cout << "Queue after dequeue: ";
    queue.display();
    return 0;
}


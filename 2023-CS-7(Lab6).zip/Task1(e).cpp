#include <iostream>
using namespace std;
struct Node 
{
    int data;
    Node* next;
};

class QueueLL 
{
private:
    Node* front;
    Node* rear;

public:
    QueueLL() 
	{
        front = rear = NULL;
    }

    bool isEmpty() 
	{
        return front == NULL;
    }

    void enqueue(int x) 
	{
        Node* newNode = new Node();
        newNode->data = x;
        newNode->next = NULL;
        if (isEmpty()) 
		{
            front = rear = newNode;
        } 
		else 
		{
            rear->next = newNode;
            rear = newNode;
        }
    }

    int dequeue() {
    	
        if (isEmpty()) {
            cout << "Queue Underflow!" << endl;
            return -1;
        }
        int temp = front->data;
        Node* delNode = front;
        front = front->next;
        if (front == NULL) 
		{
            rear = NULL;
        }
        delete delNode;
        return temp;
    }

    int peek() 
	{
        if (isEmpty()) 
		{
            cout << "Queue is empty!" << endl;
            return -1;
        }
        return front->data;
    }

    void display() 
	{
        Node* temp = front;
        while (temp != NULL) 
		{
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() 
{
    QueueLL queue;
    queue.enqueue(10);
    queue.enqueue(20);
    queue.enqueue(30);
    cout << "Queue: ";
    queue.display();
    cout << "Front element: " << queue.peek() << endl;
    cout << "Dequeued element: " << queue.dequeue() << endl;
    cout << "Queue after dequeue: ";
    queue.display();
    return 0;
}


#include <iostream>
#include <stack>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cctype>
using namespace std;
bool isInteger(const string& str) {
    if (str.empty()) 
	return false;
    int start = 0;
    // Handle negative numbers
    if (str[0] == '-') 
	{
        if (str.size()==1) 
		return false; // Just a '-' is not valid
        start = 1;  // Start checking from the next character
    }
    for (int i=start;i<str.size();i++) 
	{
        if (!isdigit(str[i])) 
		{
            return false;
        }
    }
    return true;
}
int stringToInt(const string& str) 
{
    int number = 0;
    int sign = 1;
    int i = 0;
    if (str[0]=='-') 
	{
        sign = -1;
        i = 1;  // Skip the negative sign for digit processing
    }
    for (; i < str.length(); i++) 
	{
        number=number* 10+(str[i] - '0');  // Convert char to int
    }
    return sign*number;
}
int performOperation(int operand1, int operand2, char operation) {
    switch (operation) {
        case '+': 
		return operand1 + operand2;
        case '-': 
		return operand1 - operand2;
        case '*': 
		return operand1 * operand2;
        case '/': 
		return operand1 / operand2;
        case '%': 
		return operand1 % operand2;
        default: 
		cout<<"Invalid operation";
    }
}
int main() {
    stack<int> stk;
    string input;
    cout<<"Enter postfix expression (use ! to exit): " << endl;
    while (true) {
        cin>>input;
        if (isInteger(input)) 
		{
            int num = stringToInt(input);
            stk.push(num);
        } 
        else if (input=="+"||input=="-"||input=="*"||input=="/"||input=="%") 
		{
            if(stk.size()<2) 
			{
                cout<<"Error: Not enough operands on the stack."<< endl;
                continue;
            }
            int operand2=stk.top(); 
			stk.pop();
            int operand1=stk.top(); 
			stk.pop();
            int result=performOperation(operand1, operand2, input[0]);
            stk.push(result);
        }
        else if(input=="?") 
		{
            stack<int> temp=stk;  // Make a copy of the stack to print it
            cout<<"Current Stack: ";
            while(!temp.empty()) 
			{
                cout<<temp.top()<<" ";
                temp.pop();
            }
            cout<<endl;
        }
        // Handle "^" to pop and print the top of the stack
        else if(input=="^") 
		{
            if(!stk.empty()) 
			{
                cout<<"Top element: "<<stk.top()<<endl;
                stk.pop();  // Remove the top element after printing
            } 
			else 
			{
                cout<<"Error: Stack is empty."<< endl;
            }
        }
        // Handle "!" to exit the program
        else if(input == "!") 
		{
            cout<<"Exiting..." <<endl;
            break;
        }
        // Handle invalid input
        else {
            cout<<"Error: Invalid input."<< endl;
        }
    }

    return 0;
}


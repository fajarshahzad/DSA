#include <iostream>
using namespace std;
struct Node 
{
    int data;
    Node* next;
    Node* prev;

    Node(int val) : data(val), next(NULL), prev(NULL) {}
};

class DoublyLinkedList 
{
private:
    Node* head;

public:
    DoublyLinkedList() 
	{
        head = NULL;
    }
    void insertAtHead(int x) 
	{
        Node* newNode = new Node(x);
        if (head != NULL) 
		{
            head->prev = newNode;
        }
        newNode->next = head;
        head = newNode;
    }
    void insertAtEnd(int x) 
	{
        Node* newNode = new Node(x);
        if (head == NULL) 
		{
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL) 
		{
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
    }
    bool deleteNode(int x) 
	{
        if (head == NULL) return false;

        Node* temp = head;
        while (temp != NULL && temp->data != x) 
		{
            temp = temp->next;
        }

        if (temp == NULL) return false;

        if (temp->prev != NULL) 
		{
            temp->prev->next = temp->next;
        } 
		else 
		{
            head = temp->next;
        }
        if (temp->next != NULL) 
		{
            temp->next->prev = temp->prev;
        }
        delete temp;
        return true;
    }
    void display() 
	{
        Node* temp = head;
        while (temp != NULL) 
		{
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    void reverseList() 
	{
        Node* temp = NULL;
        Node* current = head;

        while (current != NULL) 
		{
            temp = current->prev;
            current->prev = current->next;
            current->next = temp;
            current = current->prev;
        }

        if (temp != NULL) 
		{
            head = temp->prev;
        }
    }
};

int main() 
{
    DoublyLinkedList dll;
    dll.insertAtEnd(10);
    dll.insertAtEnd(20);
    dll.insertAtEnd(30);
    dll.insertAtHead(5);
    cout << "Doubly Linked List: ";
    dll.display();
    dll.deleteNode(20);
    cout << "After deleting 20: ";
    dll.display();
    dll.reverseList();
    cout << "After reversing: ";
    dll.display();
    return 0;
}


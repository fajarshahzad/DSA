#include <iostream>
#include <stack>
#include <string>
using namespace std;
void reverseString(string& str) 
{
    int start=0;
    int end=str.length()-1;
    while (start<end) {
        char temp=str[start];
        str[start]=str[end];
        str[end]=temp;
        start++;
        end--;
    }
}
string reverseSentence(const string& sentence) 
{
    stack<char> stk;
    string result="";
    for (int i=0;i<sentence.length();i++) 
	{
        if (sentence[i]!=' ') 
		{
            stk.push(sentence[i]);
        } else {
            while (!stk.empty()) 
			{
                result+=stk.top();
                stk.pop();
            }
            result+=' ';
        }
    }
    while (!stk.empty()) 
	{
        result+=stk.top();
        stk.pop();
    }
    reverseString(result); 
    return result;
}

int main() 
{
    string sentence;
    cout<<"Enter the string: ";
    getline(cin,sentence);
    string output = reverseSentence(sentence);
    cout<<"Reversed string: "<<output<<endl;
    return 0;
}



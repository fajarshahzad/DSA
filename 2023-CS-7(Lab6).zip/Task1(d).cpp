#include <iostream>
using namespace std;
struct Node 
{
    int data;
    Node* next;
};

class StackLL 
{
private:
    Node* top;

public:
    StackLL() 
	{
        top = NULL;
    }

    bool isEmpty() 
	{
        return top == NULL;
    }

    void push(int x) 
	{
        Node* newNode = new Node();
        newNode->data = x;
        newNode->next = top;
        top = newNode;
    }

    int pop() 
	{
        if (isEmpty()) 
		{
            cout << "Stack Underflow!" << endl;
            return -1;
        }
        int temp = top->data;
        Node* delNode = top;
        top = top->next;
        delete delNode;
        return temp;
    }

    int peek() {
        if (isEmpty()) 
		{
            cout << "Stack is empty!" << endl;
            return -1;
        }
        return top->data;
    }

    void display() 
	{
        Node* temp = top;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() 
{
    StackLL stack;
    stack.push(10);
    stack.push(20);
    stack.push(30);
    cout << "Stack: ";
    stack.display();
    cout << "Top element: " << stack.peek() << endl;
    cout << "Popped element: " << stack.pop() << endl;
    cout << "Stack after popping: ";
    stack.display();
    return 0;
}


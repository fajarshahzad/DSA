#include <iostream>
using namespace std;

// Node structure
struct Node {
    int data;
    Node* next;

    Node(int val) : data(val), next(NULL) {}
};

// LinkList class
class LinkList {
public:
    LinkList() 
	{ 
	head = NULL; 
	}
    ~LinkList() 
	{ 
	clearList(); 
	}
    bool isEmpty() 
	{ 
	return head == NULL; 
	}

    Node* insertNode(int index, int x) 
	{
        if (index < 0) return NULL;

        Node* newNode = new Node(x);
        if (index == 0) 
		{
            newNode->next = head;
            head = newNode;
            return head;
        }

        Node* temp = head;
        for (int i = 0; temp != NULL && i < index - 1; i++) 
		{
            temp = temp->next;
        }
        if (temp == NULL) return NULL;

        newNode->next = temp->next;
        temp->next = newNode;
        return head;
    }

    Node* insertAtHead(int x) 
	{
        Node* newNode = new Node(x);
        newNode->next = head;
        head = newNode;
        return head;
    }

    Node* insertAtEnd(int x) 
	{
        Node* newNode = new Node(x);
        if (isEmpty()) {
            head = newNode;
            return head;
        }

        Node* temp = head;
        while (temp->next != NULL) 
		{
            temp = temp->next;
        }
        temp->next = newNode;
        return head;
    }

    bool findNode(int x) 
	{
        Node* temp = head;
        while (temp != NULL) 
		{
            if (temp->data == x)
                return true;
            temp = temp->next;
        }
        return false;
    }

    bool deleteNode(int x) 
	{
        if (isEmpty()) return false;

        Node* temp = head;
        Node* prev = NULL;

        while (temp != NULL) 
		{
            if (temp->data == x) 
			{
                if (prev == NULL) 
				{
                    head = temp->next;
                } else {
                    prev->next = temp->next;
                }
                Node* toDelete = temp;
                temp = temp->next;
                delete toDelete;
            } else {
                prev = temp;
                temp = temp->next;
            }
        }
        return true;
    }

    bool deleteFromStart() 
	{
        if (isEmpty()) return false;
        Node* temp = head;
        head = head->next;
        delete temp;
        return true;
    }

    bool deleteFromEnd() 
	{
        if (isEmpty()) return false;
        if (head->next == NULL) 
		{
            delete head;
            head = NULL;
            return true;
        }

        Node* temp = head;
        while (temp->next->next != NULL)
		{
            temp = temp->next;
        }
        delete temp->next;
        temp->next = NULL;
        return true;
    }

    void displayList() 
	{
        Node* temp = head;
        while (temp != NULL) {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }

    Node* reverseList() 
	{
        Node* prev = NULL;
        Node* curr = head;
        Node* next = NULL;
        while (curr != NULL) 
		{
            next = curr->next;
            curr->next = prev;
            prev = curr;
            curr = next;
        }
        head = prev;
        return head;
    }

    Node* mergeLists(Node* list1, Node* list2) 
	{
        Node* mergedList = NULL;
        Node* tail = NULL;

        while (list1 != NULL && list2 != NULL) 
		{
            Node* temp = NULL;
            if (list1->data <= list2->data) 
			{
                temp = list1;
                list1 = list1->next;
            } else {
                temp = list2;
                list2 = list2->next;
            }
            if (mergedList == NULL) 
			{
                mergedList = temp;
                tail = temp;
            } else {
                tail->next = temp;
                tail = temp;
            }
        }

        if (list1 != NULL) tail->next = list1;
        if (list2 != NULL) tail->next = list2;

        return mergedList;
    }

private:
    Node* head;

    void clearList() {
        while (!isEmpty()) {
            deleteFromStart();
        }
    }
};

int main() {
    LinkList list1, list2;
    list1.insertAtEnd(10);
    list1.insertAtEnd(20);
    list1.insertAtEnd(30);
    list1.insertAtHead(5); // Insert at head
    cout << "List 1 after insertion: ";
    list1.displayList();
    list2.insertAtEnd(15);
    list2.insertAtEnd(25);
    list2.insertAtEnd(35);
    list2.insertAtHead(0);
    cout << "List 2 after insertion: ";
    list2.displayList();
    cout << "Is 20 in List 1? " << (list1.findNode(20) ? "Yes" : "No") << endl;
    list1.deleteNode(20);
    cout << "List 1 after deleting 20: ";
    list1.displayList();
    list1.reverseList();
    cout << "List 1 after reversal: ";
    list1.displayList();
    Node* mergedList = list1.mergeLists(list1.insertAtEnd(100), list2.insertAtEnd(200));
    cout << "Merged List: ";
    while (mergedList != NULL) 
	{
        cout << mergedList->data << " -> ";
        mergedList = mergedList->next;
    }
    cout << "NULL" << endl;

    return 0;
}


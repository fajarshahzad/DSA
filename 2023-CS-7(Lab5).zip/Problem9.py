student_name=["Fajar","Sumaira","Faraih","Minahil"]
##print("Element of list: ",student_name)
def add_student(name):
    student_name.append(name)
def remove_name(name):
    student_name.remove(name)
def display_menu():
    print("1.Add Student.")
    print("2.Remove Student.")
    print("3.Print List..")
    print("4.Exit.....")
def main_function():
    while(True):
            option=int(input("Enter the option: "))
            
            if(option==1):
                name=input("Enter the student name: ")
                add_student(name)
                print("name of students: ",student_name)
            elif(option==2):
                name=input("Enter the student name: ")
                remove_name(name)
                print("name of students: ",student_name)
            elif(option==3):
                print("name of students: ",student_name)
            elif(option==4):
                print("Exiting the program...")
                break
            else:
                print("Invalid input")
display_menu()
main_function()

import time
numbers=[]
start_time=time.time()
for i in range(0,100):
    numbers.append(i)
end_time=time.time()
run_time=end_time-start_time
print("Run time of the program is: ",run_time)
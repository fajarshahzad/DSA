numbers=[1,4,-9,5,-8,4,5,-2,1]
length=len(numbers)
sum=0
maximum=0
minimum=0
non_negatives=[]
for i in range(0,length):
    sum=sum+numbers[i]
for i in range(0,length-1):
    if(numbers[i]>numbers[i+1]):
        maximum=numbers[i]
for i in range(0,length-1):
    if(numbers[i]<numbers[i+1]):
        minimum=numbers[i]
for i in range(0,length):
    if(numbers[i]>=0):
        non_negatives.append(numbers[i])
average=sum/length
print("Average of the values is: ",average)
print("Maximum value is: ",maximum)
print("Minimum value is: ",minimum)
print("Actual list: ",numbers)
print("List after removing negatives: ",non_negatives)
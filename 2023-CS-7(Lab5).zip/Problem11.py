student_name=["Fajar","Sumaira","Faraih","Hafsa","Minahil","Arwa","Hania","Maryam","Sehrish","Khadija"]
print("nam eof students in the list: ",student_name)
std_name=input("Enter the name to search from the list: ")
found=False
for name in student_name:
    if name == std_name:
        found=True
        break
if(found):
    print("Student is present:)")
else:
    print("Student not present:(")
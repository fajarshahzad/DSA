def create_grid(rows, cols):
    grid = [[0 for _ in range(cols)] for _ in range(rows)]
    return grid
def add_row(grid, new_row):
    if len(new_row) == len(grid[0]):
        grid.append(new_row)
    else:
        print("Error: The new row must have the same number of columns as the existing grid.")
def add_column(grid, new_col):
    if len(new_col) == len(grid):
        for i in range(len(grid)):
            grid[i].append(new_col[i])
    else:
        print("Error: The new column must have the same number of rows as the existing grid.")
def display_grid(grid):
    for row in grid:
        print(row)
def sum_grid(grid):
    total_sum = 0
    for row in grid:
        for element in row:
            total_sum += element
    return total_sum
grid = create_grid(3, 3)
print("Initial Grid:")
display_grid(grid)
add_row(grid, [4, 5, 6])
print("\nGrid after adding a row:")
display_grid(grid)
add_column(grid, [7, 8, 9, 10])
print("\nGrid after adding a column:")
display_grid(grid)
total = sum_grid(grid)
print("\nSum of all elements in the grid:", total)

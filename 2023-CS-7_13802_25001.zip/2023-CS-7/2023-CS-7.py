########################PROBLEM 1#######################
def SeacrhA(array,x):
    Indexes = [] 
    for i in range(len(array)):
        if(array[i]==x): 
           Indexes.append(i)  
    return Indexes
array=[22,2,1,7,11,13,5,2,9]
print("Index finding game:")
x=input("Enter the value of the array to find its index: ")
y=int(x)
print("Index is : ",SeacrhA(array,y))
#######################PROBLEM 2#######################
def SearchB(array,x):
    Indexes=[]
    for i in range(len(array)):
        if(array[i]==x):
         Indexes.append(i)
        if(array[i]>x):
         return Indexes
    return Indexes
Sorted_Array=[1,2,2,5,7,9,11,13,23]
num=int(input("Enter a number: "))
print(SearchB(Sorted_Array,num))
####################PROBLEM 3 ############################
def Minimum(array,start,stop):
  min_index=start
  for i in range(start,stop+1):
    if array[i]<array[min_index]:
      min_index=i
  return min_index
array=list(map(int,input("Enter the elements of array with spaces: ").split()))
start=int(input("Enter the starting index: "))
stop=int(input("Enter the ending index: "))
result=(Minimum(array,start,stop))
print("The index of the minimum value is: ",result)
######################PROBLEM 4 ##########################
def Sort4(array):
  for i in range(len(array)):
    min_index=i
    for j in range(i+1,len(array)):
      if array[min_index]>array[j]:
       min_index=j
    array[i],array[min_index]=array[min_index],array[i]
  return array

array=list(map(int,input("Enter the value of the array to be sorted with spaces: ").split()))
indices=Sort4(array)
print("The Sorted Array is: ",indices)
#######################PROBLEM 5 ########################
def StringReverse(string,start,stop):
    selected_string = string[start:stop]
    return selected_string[::-1]
string=input("Enter the string: ")
start=int(input("Enter the start index: "))
stop=int(input("Enter the stop index: "))
result=(StringReverse(string,start,stop))
print("The reverse string is: ",result)
####################PROBLEM 6#########################
def SumItertative(number):
    sum = 0
    while(number != 0):
        i = number % 10
        number = number // 10
        sum += i
    return sum
def SumRecursive(number):
    if(number == 0):
        return 0
    else:
        i = number % 10
        number = number // 10
        return i + SumRecursive(number)
num = int(input("Enter a number: "))
result=(SumItertative(num))
result1=(SumRecursive(num))
print("The sum of these digits by recursive method is :",result1)
print("The sum of these digits by iterative method is :",result)
###########################PROBLEM 7 ###########################
def RowWiseSum(matrix):
    return [sum(row) for row in matrix]
def ColumnWiseSum(matrix):
    number_of_columns = len(matrix[0])
    col_sums = [0] * number_of_columns
    for row in matrix:
        for i in range(number_of_columns):
            col_sums[i] += row[i]
    return col_sums
A = [[1, 13, 13],[5, 11, 6],[4, 4, 9]]
row_sum = RowWiseSum(A)
column_sum = ColumnWiseSum(A)
print("Row-wise sum:", row_sum)
print("Column-wise sum:", column_sum)
###########################PROBLEM 8 ###########################
def SortedMerge(array1, array2):
    i, j = 0, 0
    result = [] 
    while i < len(array1) and j < len(array2):
        if array1[i] <= array2[j]:
            result.append(array1[i])
            i += 1
        else:
            result.append(array2[j])
            j += 1
    for k in range(i, len(array1)):
        result.append(array1[k])
    for k in range(j, len(array2)):
        result.append(array2[k])

    return result
array1 = [0, 3, 4, 10, 11]
array2 = [1, 8, 13, 24]
sorted_result = SortedMerge(array1, array2)
print("Resulting array is:", sorted_result)
###########################PROBLEM 9 ###########################
def PalindromRecursive(string):
    if len(string) < 2:
        return True
    if string[0] != string[-1]:
        return False
    return PalindromRecursive(string[1:-1])
string=input("Enter a string: ")
result=PalindromRecursive(string)
if result:
    print("The string is a palindrome.")
else:
    print("The string is not a palindrome.")
###########################PROBLEM 10 ###########################
def Sort10(Array):
    negative_numbers = []
    positive_numbers = []
    sorted_array = []
    for x in Array:
        if(x<0):
            negative_numbers.append(x)
        else:
            positive_numbers.append(x)
    negative_numbers.sort()
    positive_numbers.sort()
    n = min(len(negative_numbers), len(positive_numbers))
    for i in range(n):
        sorted_array.append(negative_numbers[i])
        sorted_array.append(positive_numbers[i])
    if len(negative_numbers) > n:
        sorted_array.extend(negative_numbers[n:])
    if len(positive_numbers) > n:
        sorted_array.extend(positive_numbers[n:])
    return sorted_array
arr = [10, -1, 9, 20, -3, -8, 22, 9, 7]
sorted_arr = Sort10(arr)
print("The array after sorting the positive and negative numbers in ascending order is : ",sorted_arr)
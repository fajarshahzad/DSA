def BucketSort(array):
    length=len(array)
    output_array=[]
    number_of_buckets=[[]for _ in range(length)]
    for num in array:
        index=int(length*num)
        number_of_buckets[index].append(num)
    for bucket in number_of_buckets:
        bucket.sort()
    for bucket in number_of_buckets:
        output_array.extend(bucket)
    return output_array
## main
array=[0.897,0.565,0.656,0.1234,0.665,0.3434]
result=BucketSort(array)
print("Sorted array is :",result)
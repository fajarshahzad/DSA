def k_select(array,k):
    array.sort()
    k_value=array[k-1]
    return k_value
##main
array=[7,10,4,3,20,15]
k=int(input("Enter the value of k-th element to find: "))
index=k_select(array,k)
print(f"The {k}th smallest element is : ",index)
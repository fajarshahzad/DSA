def partition(array,p,r):## this is the quick sort in which the pivot is selected as the last element of the array 
    x=array[r]
    i=p-1
    for j in range(p,r):
        if(array[j]<=x):
            i=i+1
            array[i],array[j]=array[j],array[i]
    array[i+1],array[r]=array[r],array[i+1]
    return i+1
def QuickSort(array,p,r):
    if(p<r):
        q=partition(array,p,r)
        QuickSort(array,p,q-1)
        QuickSort(array,q+1,r)
#### main
array=[30,50,15,25,80,20,90,45]
p=0
r=len(array)-1
QuickSort(array,p,r)
print("Sorted Array: ",array)
def CountingSort(array):
    min_val=min(array) 
    k=max(array)-min_val
    intermediate_array=[0]*(k + 1)
    output=[]
    for j in array:
        intermediate_array[j-min_val]+=1
    for i in range(len(intermediate_array)):
        for _ in range(intermediate_array[i]):
            output.append(i+min_val) 
    return output
# Main
array=[-5, -10, 0, -3, 8, 5, -1, 10]
result=CountingSort(array)
print("Sorted array:",result)

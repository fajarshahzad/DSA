def partition(arr, p, r):
    x = arr[p]  # The first element is chosen as the pivot
    a = r          # a starts from the last element
    for b in range(p + 1, r + 1): 
        while b <= a and arr[a] >= x:
            a -= 1
        if b>= a:## Here the a and b cross each other
            break
        if arr[b] > x:
            arr[b], arr[a] = arr[a], arr[b]
    # Swap the pivot with the element
    arr[p], arr[a] = arr[a], arr[p]
    return a 
def Quick_Sort(array, p, r):
    if p<r:
        q = partition(array, p, r)
        Quick_Sort(array, p, q - 1)
        Quick_Sort(array, q + 1,r)

# main
array = [30, 50, 15, 25, 80, 20, 90, 45]
n = len(array)
Quick_Sort(array, 0, n - 1)
print("Sorted array:", array)
